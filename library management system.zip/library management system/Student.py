# -*- coding: utf-8 -*-
class Student:
    def requestBook(self):
            print("Enter the name of the book you'd like to borrow>>")
            self.book=input()
            return self.book
    def returnBook(self):
                print("Enter the name of the book you'd like to return>>")
                self.book=input()
                return self.book
