# -*- coding: utf-8 -*-
from Book import Book
from Catalog import Catalog
from User import Member, Librarian

b1 = Book('kannada','kannadiga', '2011',312)
b1.addBookItem('129hg','H1B9')
b1.addBookItem('125hg','H1B5')

b1.printBook()

catalog = Catalog()

b = catalog.addBook('kannada','kannadiga', '2011',312)
catalog.addBookItem(b, '129hg','H1B9')
catalog.addBookItem(b, '125hg','H1B5')
catalog.addBookItem(b, '125hg','H1B5')

b = catalog.addBook('Ramayana','valmiki', '1939',318)
catalog.addBookItem(b, '463hg','K1B2')

b = catalog.addBook('wings of fire ','APJ Kalam', '1985',319)
catalog.addBookItem(b, '473hg','K1B3')

b = catalog.addBook('mahabharatha','vyasa', '1900',320)
catalog.addBookItem(b, '483hg','K1B4')

catalog.displayAllBooks()

m1 = Member("taibu","hassan",23,'asljlkj22','std1233')

librarian = Librarian("Sagar","Bangalore",23,'asljlkj22','zeke101') 
print (m1)
print (librarian)

b = catalog.searchByName('kannada')
print (b)

b = catalog.searchByName('wings of fire')
print (b)

b = catalog.searchByAuthor('vyasa')
print (b)

#catalog.removeBookItem('kannada','129hg')
#catalog.displayAllBooks()
#m1.issueBook

b = catalog.RequestBook("")
print (b,"Book issued Successfully")

b = catalog.returnBook('')
print (b,"Book returned Successfully Thank you")

